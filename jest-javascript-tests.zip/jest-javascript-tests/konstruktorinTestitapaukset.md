# Konstruktorin testitapaukset

## testataan puuttuva parametri

```js
new Tietokonerekisteri()
```

aiheuttaa `'tiedot puuttuvat'`

