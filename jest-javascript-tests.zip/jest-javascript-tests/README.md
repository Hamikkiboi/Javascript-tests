# Javascript testing with jest
 This is a school project, which helped me understand the fundamentals of javascript testing.
 I've made methods that handle pre-gien json data, then made multiple jest tests that make sure the methods are working correctly.
 (the project folder has markdown files which include documentation for testing and methods)
 
 
 ## Using the program
 * Clone the repository:
 `git clone https://github.com/lraivisto/jest-javascript-tests`
 
 * In the repository folder, install needed packages:
 `npm i`
 
 * Run the tests:
 `npm test`
